<?php  
session_start();  
?> 
<?php
		session_destroy();  
		header("Location:http://localhost/Practice/Egg%20Cart%20Final/home.php");
		
?>

