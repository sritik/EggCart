<head>
    <title>cart</title>
    <script src="https://use.fontawesome.com/12546cfb1f.js"></script>
</head>
<body class="bg-warning">
    <section>
        <!--include navbar here-->
        <?php 
            require('customer_navbar.php');
        ?>
    </section>

    <section>
    	<div class="container mt-5">
    		<div class="card col-12">
				<div class="card-body">
					<h1 class="card-title" align="center">YOUR CART</h1>
					<table class="table table-bordered text-center">
						<thead>
							<tr>
							<th scope="col">#</th>
							<th scope="col">Product</th>
							<th scope="col">Product Name</th>
							<th scope="col">Price</th>
							<th scope="col">Quantity</th>
							<th scope="col">Total</th>
							<th scope="col">Remove</th>
							</tr>
						</thead>
						<tbody>
							
								<?php 
									$sum=0;
									if(isset($_SESSION["shopping_cart"]))
									{
										require('connection.php');
											$i=1;
											
										
											foreach($_SESSION["shopping_cart"] as $p)
											{
												
													$query="select p_name,p_quantity,p_price,p_photo from product where p_id=".$p['item_id'];
												
											
											$result=mysqli_query($conn,$query);
											$row_count=mysqli_num_rows($result);
											while($row=mysqli_fetch_assoc($result)) 
											{
								?>
								<tr>
								<th scope="row"><?php echo $i++; ?></th>
								<td><img src="Product/<?php echo $row['p_photo']; ?>" alt="" height="200" width="300px"></td>
								<td><?php echo $row['p_name']; ?></td>
								<td><?php echo "&#8377;".$row['p_price']; ?></td>
								<td><?php echo $p['item_quantity']; ?></td>
								<td><?php echo "&#8377;".$row['p_price']*$p['item_quantity']; ?></td>
								<td><a href="http://localhost/Practice/Egg%20Cart%20Final/Customer/Cart_manager.php?delete_id=<?php echo $p['item_id']; ?>"><i class="fa fa-trash fa-2x"></i></a></td>
								</tr>
								<?php 
										$sum=$sum+$row['p_price']*$p['item_quantity'];
											}
										}
									}
								?>
							
								
							<tr>
								<td colspan="7" align="center"><b>Total Bill: &#8377;<?php echo $sum ?></b></td>
							</tr>
							<tr>
								<?php
									if($sum==0)
									{
										echo"<td colspan=\"7\" align=\"center\"><a class=\"btn btn-warning disabled \" href=\"Order_manager.php\" role=\"button\" >Order</a></td>";
									}
									else
									{
										echo"<td colspan=\"7\" align=\"center\"><a class=\"btn btn-warning \" href=\"Order_manager.php\" role=\"button\">Order</a> <a class=\"btn btn-warning \" href=\"http://localhost/Practice/Egg%20Cart%20Final/Customer/Cart_manager.php?Clean=1\" role=\"button\">Clear</a></td>";
									}
									
								?>
								
							</tr>
						</tbody>
					</table>
					
				</div>
			</div>
    	</div>
    </section>
</body>
