<?php  
session_start();  
?> 
<?php  
	function searchForId($id, $array) {
	   foreach ($array as $key => $val)
	   {
		   if ($val['item_id'] === $id) {
			   return $key;
		   }
	   }
	   return null;
	}
	
		$id=0;
		
	if(isset($_POST["Add_to_cart"]))
	{	$id=$_POST["p_id"];
		$quantity=$_POST["p_quantity"];
		if(isset($_SESSION["shopping_cart"]))
		{
			$item_array_id = array_column($_SESSION["shopping_cart"], "item_id");
			if(!in_array($id, $item_array_id))
			{
				$count = count($_SESSION["shopping_cart"]);
				$item_array = array(
				'item_id'		=>	$id,
				'item_quantity'		=>	$quantity
				);
				$_SESSION["shopping_cart"][$count] = $item_array;
			}
			else
			{
				$key= searchForId($id,$_SESSION["shopping_cart"]);
				$_SESSION["shopping_cart"][$key]['item_quantity']=	$quantity;
			}
		}
		else
		{
			$item_array = array(
			'item_id'		=>	$id,
			'item_quantity'		=>	$quantity
			);
			$_SESSION["shopping_cart"][0] = $item_array;
		}
		
		header("Location:home.php");
		
	}
	
	if(isset($_GET["delete_id"]))
	{
		$key=0;
		$id=$_GET["delete_id"];
		foreach($_SESSION["shopping_cart"] as $keys=>$values) 
		{ 
			if($_SESSION["shopping_cart"][$keys]['item_id']==$id)
			{
				$key=$keys;
				$flag=1;
				break;
			}
			
		}
		if(isset($flag))
		{
			unset ($_SESSION["shopping_cart"][$keys]);
		}
		header("Location:cart.php");
	}
	
	if(isset($_GET["Clean"]))
	{
		unset($_SESSION["shopping_cart"]);
		header("Location:cart.php");
	}
	
	
?>
