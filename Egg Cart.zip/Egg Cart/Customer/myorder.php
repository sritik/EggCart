<head>
    <title>my order</title>
</head>
<body class="bg-warning">
    <section>
        <!--include navbar here-->
        <?php 
            require('customer_navbar.php');		
			require('connection.php');
			$i=1;
			$query="SELECT o.invoice_no, o.date, p.p_name, p.p_price, o.quantity_ordered, o.bill, o.status  FROM order_egg o INNER JOIN product p ON o.product_id = p.p_id where customer_id=(select id from customer where email='".$_SESSION["email"]."')";
			$result=mysqli_query($conn,$query);
			mysqli_close($conn);
			$row_count=mysqli_num_rows($result);
        ?>
    </section>

    <section>
    	<div class="container mt-5">
    		<div class="card col-12">
				<div class="card-body">
					<h1 class="card-title" align="center">YOUR ORDER</h1>
					<table class="table table-bordered">
						<thead>
							<tr>
							<th scope="col">#</th>
							<th scope="col">Invoice No</th>
							<th scope="col">Date</th>
							<th scope="col">Product Name</th>
							<th scope="col">Price</th>
							<th scope="col">Quantity</th>
							<th scope="col">Total</th>
							<th scope="col">Status</th>
							</tr>
						</thead>
						<tbody>
						<?php while($row=mysqli_fetch_assoc($result)) 
						{?>
						
							<tr>
								<th scope="row"><?php echo $i++ ;?></th>
								<td><?php echo $row['invoice_no'];?></td>
								<td><?php echo $row['date'];?></td>
								<td><?php echo $row['p_name'];?></td>
								<td>&#8377;<?php echo $row['p_price'];?></td>
								<td><?php echo $row['quantity_ordered'];?></td>
								<td>&#8377;<?php echo $row['bill'];?></td>
								<td><?php echo $row['status'];?></td>
							</tr>
						<?php }?>
						</tbody>
					</table>
				</div>
			</div>
    	</div>
    </section>
</body>
