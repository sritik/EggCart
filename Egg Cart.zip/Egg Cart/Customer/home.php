<!DOCTYPE html>
<head>
    <title>home</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
</head>
<body class="bg-warning">
    <section>
        <!--include navbar here-->
		<!--Load Category Here-->
        <?php 
            require('customer_navbar.php');
			require('connection.php');
			
			
			$query="select category_name, category_id from category";
			$result=mysqli_query($conn,$query);
		
			$row_count=mysqli_num_rows($result);
        ?>
    </section>
	
<section class="banner cover-bg">
	<div class="container h-100">
		<div class="row align-items-center h-100">
			<div class="col-12 caption text-center">
				<h2 class="mt-20">EGG CART</h2>
				<p class="mt-20">Highest Quality EGG  Provider</p>
				<div class="social_icon text-center mt-20">
					<a href="#"><span><i class="fa fa-facebook"></i></span></a>
					<a href="#"><span><i class="fa fa-instagram"></i></span></a>
					<a href="#"><span><i class="fa fa-twitter"></i></span></a>
					<a href="#"><span><i class="fa fa-youtube-play"></i></span></a>
				</div>
			</div>
		</div>
	</div>
</section>
   
   
<section>
	<div class="container category_product_size">
	    <div class="row">
	    	<!--category here-->
			<div class="col-lg-3">
				<div class="list-group text-center">
								<a href="http://localhost/Practice/Egg%20Cart%20Final/Customer/home.php" class="list-group-item">All</a>
				<?php if($row_count>0)
						{
							while($row=mysqli_fetch_assoc($result)) 
							{?>
								<a href="http://localhost/Practice/Egg%20Cart%20Final/Customer/home.php?Catergory=<?php echo $row['category_id'];?>" class="list-group-item"><?php echo $row['category_name'];?></a>
							<?php
							}
						}
					
					?>
				</div>
			</div>
			
			<!--Load Products Here here-->
			<?php
				if(isset($_GET["Catergory"]))
				{
					$query="select * from product where category_id=".$_GET["Catergory"];
				}
				else
				{
					$query="select * from product";
				}
				
				
				$result=mysqli_query($conn,$query);
				
				$row_count=mysqli_num_rows($result);
					
			?>
					

			<!--product here-->
			<div class="col-lg-9">
				<div class="row">
				<?php
					while($row=mysqli_fetch_assoc($result)) 
					{
				?>
				<?php ?>
				<div class="col-lg-4 col-md-6 mb-4">
					<div class="card h-100">
						<form action="http://localhost/Practice/Egg%20Cart%20Final/Customer/Cart_manager.php" method="post">
							<a href="#"><img class="card-img-top" src="Product/<?php echo $row['p_photo']; ?>" alt="" height="200"></a>
							<div class="card-body">
								<h6 class="card-title">
								  <input type="hidden" name="p_id" value="<?php echo $row['p_id']; ?>" class="form-control">
								  <a href="#"><?php echo $row['p_name']; ?></a>
								</h6>
								<p class="card-text">&#8377;<?php echo $row['p_price']; ?></p>
								Quantity:
								<select name="p_quantity" class="custom-select form-control" width="20px">
								<?php for($i=1;$i<=$row['p_quantity'];$i++)
								{
								?>
									<option value="<?php echo $i; ?>"><?php echo $i; ?></option>
								<?php	
								}								
								?>
								</select>
							</div>
						  <div class="card-footer text-center">
								<button type="submit" name="Add_to_cart" class="btn btn-warning">Add to cart</button>
						  </div>
						</form>
					</div>
				</div>
				<?php
					}
				?>
				</div>
			</div>
		</div>
	</div>
</section>
<footer class="footer-design">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="siteinfo">
					<p>Copyright © Untitled. All rights reserved. Design By
					<a href="#">VTI Group 2</a>
					</p>
				</div>
				<div class="footer-menu">
					<ul>
						<li>
							<a href="#">HOME -</a>
							<a href="#">COMPARE -</a>
							<a href="#">CART -</a>
							<a href="#">CONTACT US -</a>
							<a href="#">ABOUT US  -</a>
							<a href="#">LOGIN -</a>
							<a href="#">REGISTER </a>
						</li>
					</ul>
				</div>
				<div class="footer-social">
					<a href="#"><span><i class="fa fa-facebook"></i></span></a>
					<a href="#"><span><i class="fa fa-instagram"></i></span></a>
					<a href="#"><span><i class="fa fa-twitter"></i></span></a>
					<a href="#"><span><i class="fa fa-youtube-play"></i></span></a>
				</div>
			</div>
		</div>
	</div>
</footer>
</body>
