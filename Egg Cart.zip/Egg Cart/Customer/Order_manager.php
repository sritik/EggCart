<?php  
session_start();  
?> 
<?php
	//Declare Variables ,Get Invoice,Date
	$order_quantity=0;
	$order_bill=0;
	$order_invoice=strtotime("now")-1604060000;
	$date=date("Y-m-d");
	$c_id=0;
	require('connection.php');

	//Get Customer_id
	$query="select id from customer where email='".$_SESSION["email"]."'";
	$result=mysqli_query($conn,$query);
		
        if (mysqli_num_rows($result)!=0)
        {
            $row=mysqli_fetch_assoc($result);
			$c_id=$row["id"];
		}
	//Enter Data in Order
	foreach($_SESSION["shopping_cart"] as $p)
	{
		$query="select p_quantity,p_price from product where p_id=".$p['item_id'];
		$result=mysqli_query($conn,$query);
		$row_count=mysqli_num_rows($result);
		while($row=mysqli_fetch_assoc($result)) 
		{
			$order_quantity=$p['item_quantity'];
			$order_bill=$row['p_price']*$order_quantity;
			$query="insert into order_egg(Invoice_No,Date,Customer_id,Product_id, Quantity_Ordered, Bill) values('T".$order_invoice."','".$date."',".$c_id.",".$p['item_id'].",".$order_quantity.",".(int)$order_bill.")";
			$order_quantity=$row['p_quantity']-$p['item_quantity'];
			mysqli_query($conn,$query);
			$affected=mysqli_affected_rows($conn);
		
			if($affected>0)
			{
				echo"<script>alert(\"Sucess\");</script>";
			}
			else
			{
				echo"<script>alert(\"Something went Wrong\");</script>";
			}
			$query="update product set p_quantity='".(int)$order_quantity."'  where p_id=".$p['item_id'];
			mysqli_query($conn,$query);
		}
	}
		
		mysqli_close($conn);
		
	
	
?>
