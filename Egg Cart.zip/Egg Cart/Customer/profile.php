<head>
    <title>profile</title>
</head>
<body class="bg-warning">
    <section>
        <!--include navbar here-->
        <?php 
            require('customer_navbar.php');
        ?>
    </section>

    <section>
        <div class="container">
            <div class="card col-8 offset-2 mt-5">
                <div class="card-body">
                    <h1 class="card-title" align="center">YOUR PROFILE</h1>
                    <form action="#" method="post">
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input name="user_name" type="text" class="form-control" id="name">
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input name="user_email" type="email" class="form-control" id="email">
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input name="user_password" type="password" class="form-control" id="password">
                        </div>
                        <div class="form-group">
                            <label for="phone">Phone number</label>
                            <input name="user_phone" type="number" class="form-control" id="phone">
                        </div>
                        <div class="form-group">
                            <label for="address">Address</label>
                            <textarea name="user_address" class="form-control" id="address"></textarea>
                        </div>
                        <div class="container text-center">
                            <button type="submit" class="btn btn-warning">Save Changes</button>
                            <button type="submit" class="btn btn-secondary">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
</body>
    