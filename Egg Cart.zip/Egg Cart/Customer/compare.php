<head>
    <title>compare</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body class="bg-warning">
    <section>
        <!--include navbar here-->
        <?php 
            require('customer_navbar.php');
        ?>
    </section>


<section>
    <div class="container">
        <div class="card col-10 offset-1 mt-5 mb-5">
            <div class="card-body">
                <h1 class="card-title" align="center">COMPARE PRODUCTS</h1>

                <?php
                    require("connection.php");

                    if($_SERVER['REQUEST_METHOD']=='POST')
                    {
                        $product1=$_POST["product1"];
                        $product2=$_POST["product2"];         

                        $query = "select * from product where name='$product1' or name='$product2'";

                        $result = mysqli_query($conn,$query);
                        $num = mysqli_num_rows($result);

                        /*if($num > 0)
                        {
                            echo "success";
                        }
                        else
                        {
                             echo "fail";
                        }*/

                    }
                ?>
                <form action="#" method="post">

                	<div class="row">
						<div class="form-group col-md-6">
							<input name="product1" type="text" class="form-control" placeholder="Enter 1st product">
						</div>
						<div class="form-group col-md-6">
							<input name="product2" type="text" class="form-control" placeholder="Enter 2nd product">
						</div>
					</div>		

                    <div class="container text-center">
                        <button type="submit" class="btn btn-warning">Compare</button>
 					</div>

                </form>

                <div class="container">
				    <div class="row">
						<div class="col-lg-6 col-md-6 mb-4">
							<div class="card h-100">
								<a href="#">
                                    <img class="card-img-top" src="
                                    <?php
                                            if (isset($product1))
                                            {
                                                $sql = "select photo from product where name='$product1'";
                                                $result = $conn->query($sql);

                                                if ($result->num_rows > 0)
                                                {
                                                    while($row = $result->fetch_assoc())
                                                    {
                                                        echo $row["photo"];
                                                    }
                                                }
                                                else
                                                {
                                                    echo "";
                                                }
                                            }
                                    ?>
                                        "  alt="product 1 image here" height="200">
                                </a>
								<div class="card-body">
									<h4 class="card-title">
										<a href="#">
                                            <?php
                                                if (isset($product1))
                                                {
                                                    $query = "select name from product where name='$product1'";

                                                    $result = mysqli_query($conn,$query);
                                                    $num = mysqli_num_rows($result);

                                                    if($num > 0)
                                                    {
                                                        echo ($product1);
                                                    }
                                                    else
                                                    {
                                                         echo " please enter correct product";
                                                    }
                                                }
                                            ?>
                                         </a>
									</h4>
									<h5>
                                        <?php
                                            if (isset($product1))
                                            {
                                                $sql = "select price from product where name='$product1'";
                                                $result = $conn->query($sql);

                                                if ($result->num_rows > 0)
                                                {
                                                    while($row = $result->fetch_assoc())
                                                    {
                                                        echo "Rs : " . $row["price"]."<br>";
                                                    }
                                                }
                                                else
                                                {
                                                    echo "";
                                                }
                                            }
                                        ?>      
                                    </h5>
                                    <p class="card-text">
                                         <?php
                                            if (isset($product1))
                                            {
                                                $sql = "select description from product where name='$product1'";
                                                $result = $conn->query($sql);

                                                if ($result->num_rows > 0)
                                                {
                                                    while($row = $result->fetch_assoc())
                                                    {
                                                        echo "Description : " . $row["description"]."<br>";
                                                    }
                                                }
                                                else
                                                {
                                                    echo "";
                                                }
                                            }
                                        ?>      
                                    </p>
								</div>
								<div class="card-footer text-center">
									<button type="submit" class="btn btn-warning">Add to cart</button>
								</div>
							</div>
						</div>

						<div class="col-lg-6 col-md-6 mb-4">
							<div class="card h-100">
								<a href="#">
                                    <img class="card-img-top" src="
                                    <?php
                                            if (isset($product2))
                                            {
                                                $sql = "select photo from product where name='$product2'";
                                                $result = $conn->query($sql);

                                                if ($result->num_rows > 0)
                                                {
                                                    while($row = $result->fetch_assoc())
                                                    {
                                                        echo $row["photo"];
                                                    }
                                                }
                                                else
                                                {
                                                    echo "";
                                                }
                                            }
                                    ?>
                                        "  alt="product 2 image here" height="200">
                                </a>
								<div class="card-body">
									<h4 class="card-title">
										<a href="#">
                                            <?php
                                              if (isset($product2))
                                                {
                                                    $query = "select name from product where name='$product2'";
                                            
                                                    $result = mysqli_query($conn,$query);
                                                    $num = mysqli_num_rows($result);

                                                    if($num > 0)
                                                    {
                                                        echo ($product2);
                                                    }
                                                    else
                                                    {
                                                         echo " please enter correct product";
                                                    }
                                                }
                                            ?>                              
                                        </a>
									</h4>
									<h5>
                                        <?php
                                            if (isset($product2))
                                            {
                                                $sql = "select price from product where name='$product2'";
                                                $result = $conn->query($sql);

                                                if ($result->num_rows > 0)
                                                {
                                                    while($row = $result->fetch_assoc())
                                                    {
                                                        echo "Rs : " . $row["price"]."<br>";
                                                    }
                                                }
                                                else
                                                {
                                                    echo "";
                                                }
                                            }
                                        ?>      
                                    </h5>
									<p class="card-text">
                                         <?php
                                            if (isset($product2))
                                            {
                                                $sql = "select description from product where name='$product2'";
                                                $result = $conn->query($sql);

                                                if ($result->num_rows > 0)
                                                {
                                                    while($row = $result->fetch_assoc())
                                                    {
                                                        echo "Description : " . $row["description"]."<br>";
                                                    }
                                                }
                                                else
                                                {
                                                    echo "";
                                                }
                                            }
                                        ?>      
                                    </p>
								</div>
								<div class="card-footer text-center">
									<button type="submit" class="btn btn-warning">Add to cart</button>
								</div>
							</div>
						</div>
					</div>
				</div>
            </div>
        </div>
    </div>
</section>

<footer class="footer-design">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="siteinfo">
                        <p>Copyright © Untitled. All rights reserved. Design By
                        <a href="#">VTI Group 2</a>
                        </p>
                    </div>
                    <div class="footer-menu">
                        <ul>
                            <li>
                                <a href="#">HOME -</a>
                                <a href="#">COMPARE -</a>
                                <a href="#">CART -</a>
                                <a href="#">CONTACT US -</a>
                                <a href="#">ABOUT US  -</a>
                                <a href="#">LOGIN -</a>
                                <a href="#">REGISTER </a>
                            </li>
                        </ul>
                    </div>
                    <div class="footer-social">
                        <a href="#"><span><i class="fa fa-facebook"></i></span></a>
                        <a href="#"><span><i class="fa fa-instagram"></i></span></a>
                        <a href="#"><span><i class="fa fa-twitter"></i></span></a>
                        <a href="#"><span><i class="fa fa-youtube-play"></i></span></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>

</body>