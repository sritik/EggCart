<?php
	$name=$_POST["name"];
	$email=$_POST["email"];
	$pass=$_POST["password"];
	$mobile=$_POST["mobile"];
	$address=$_POST["address"];
	
	
	
		require("connection.php");
		$query="insert into customer(name, email, password, mobile, address) values('".$name."','".$email."','".$pass."','".$mobile."','".$address."')";
		
		mysqli_query($conn,$query);
		
		$affected=mysqli_affected_rows($conn);
		
		if($affected>0)
		{
			header("Location:Login.php");
		}
		else
		{
			echo"<script>alert(\"Something went Wrong\");</script>";
		}
		
		
		mysqli_close($conn);
	
?>