<head>
    <title>about us</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body class="bg-warning">
    <section>
        <!--include navbar here-->
        <?php 
            require('main_navbar.php');
        ?>
    </section>

    <section>
    	<div class="container">
	    	<div class="image">
		    	<img class="image__img" src="img/aboutusbg.jpg" alt="about us" height="400">
		    	<div class="image__overlay image__overlay--primary">
		       		<div class="image__title">About Us</div>
		    	</div>
			</div>
		</div>
    </section>

    <section>
    	<div class="container mt-5">
			<div class="card col-12">
				<div class="card-body">
					<ul>
						<li class="m-3"><h5>We all make choices in life. At the EggCart.com, we choose to make ours maximize health and happiness.</h5></li>
						<li class="m-3"><h5>Our mission is establishing sustainable egg farming.</h5></li>
						<li class="m-3"><h5>EggCart.com employees over hundreds people in our Mumbai, Delhi headquarters and over 60 farmer families who produce our great-tasting eggs!</h5></li>
						<li class="m-3"><h5>We start by hiring farmers who care and who take as much pride as we do in raising the healthiest hens, that can lay the best-tasting, farmers’-market-quality eggs for our customers.</h5></li>
						<li class="m-3"><h5>We only work with small family farms to make sure our hens receive close, daily care and attention.</h5></li>
						<li class="m-3"><h5> To keep exceeding our world-class standards, we inspect each farm on a regular basis and conduct monthly farm checks and unannounced audits.</h5></li>
					</ul>
				</div>
			</div>
		</div>
    </section>

    <section class="aboutus">
    	<div class="container">
    		<div class="row">
    			<div class="col-4">
    				<div class="card m-3">
						<img src="https://cdn.psychologytoday.com/sites/default/files/styles/image-article_inline_full/public/field_blog_entry_images/2018-09/shutterstock_648907024.jpg?itok=ji6Xj8tv" class="card-img-top" alt="..." height="200">
						<div class="card-body">
							<h5 class="card-title">Owner</h5>
							<p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
						</div>
					</div>
    			</div>

    			<div class="col-4">
    				<div class="card m-3">
						<img src="https://assets.bwbx.io/images/users/iqjWHBFdfxIU/ikRHGbiXJL8o/v0/1000x-1.jpg" class="card-img-top" alt="..." height="200">
						<div class="card-body">
							<h5 class="card-title">Co-Owner</h5>
							<p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
						</div>
					</div>

    			</div>

    			<div class="col-4">
    				<div class="card m-3">
						<img src="https://www.gannett-cdn.com/presto/2020/08/17/USAT/b95604a7-451a-4b42-a59a-bdff1cc71d1c-5bAV37fB.jpeg" class="card-img-top" alt="..." height="200">
						<div class="card-body">
							<h5 class="card-title">Marketing head</h5>
							<p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
						</div>
					</div>
    			</div>

    			
		
    		</div>
    	</div>
    </section>
    <footer class="footer-design">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="siteinfo">
					<p>Copyright © Untitled. All rights reserved. Design By
					<a href="#">VTI Group 2</a>
					</p>
				</div>
				<div class="footer-menu">
					<ul>
						<li>
							<a href="#">HOME -</a>
							<a href="#">COMPARE -</a>
							<a href="#">CART -</a>
							<a href="#">CONTACT US -</a>
							<a href="#">ABOUT US  -</a>
							<a href="#">LOGIN -</a>
							<a href="#">REGISTER </a>
						</li>
					</ul>
				</div>
				<div class="footer-social">
					<a href="#"><span><i class="fa fa-facebook"></i></span></a>
					<a href="#"><span><i class="fa fa-instagram"></i></span></a>
					<a href="#"><span><i class="fa fa-twitter"></i></span></a>
					<a href="#"><span><i class="fa fa-youtube-play"></i></span></a>
				</div>
			</div>
		</div>
	</div>
</footer>
</body>
