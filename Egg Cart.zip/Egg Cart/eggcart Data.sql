-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 31, 2020 at 03:42 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eggcart`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(40) NOT NULL,
  `category_description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`, `category_description`) VALUES
(2, 'White chicken eggs', 'White chicken eggs that are rich in proteins, calcium and zinc'),
(3, 'Caviar', 'Caviar is rich in antioxidants and they contain a wealth of sea minerals.'),
(5, 'Brown Eggs', 'Brown chicken eggs that are rich in proteins, calcium and zinc'),
(6, 'Quail Eggs', 'They are slightly richer in Vitamin D and also Vitamin B12.'),
(7, 'Duck Eggs', 'Their yolk is usually slightly larger than the chicken eggs. Thus, it has more fat and protein conte');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(50) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `address` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `name`, `email`, `password`, `mobile`, `address`) VALUES
(1, 'abc', 'abc@outlook.com', 'abc', '123', 'abcd'),
(2, 'def', 'def@gmail.com', 'def', '456', 'defg'),
(3, 'priti', 'priti@gmail.com', 'priti', '123456789', 'zxcvbnm'),
(4, 'xyz', 'xyz@gmail.com', 'xyz', '12346878', 'zxy'),
(9, 'Chaitanya Agarwal', 'chaipanch98@gmail.com', 'Chaitanya', '2147483647', 'Chaitanya'),
(14, 'Sunil Wani', 'Sunil56@gmail.com', 'Sunil', '2147483647', 'Bhyander West'),
(17, 'Suruchi Tiwari', 'Suruchi@mail.com', 'Suruchi', '9699115678', 'Bhyander West');

-- --------------------------------------------------------

--
-- Table structure for table `order_egg`
--

CREATE TABLE `order_egg` (
  `order_id` int(11) NOT NULL,
  `invoice_no` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `customer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity_ordered` int(11) NOT NULL,
  `bill` int(11) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_egg`
--

INSERT INTO `order_egg` (`order_id`, `invoice_no`, `date`, `customer_id`, `product_id`, `quantity_ordered`, `bill`, `status`) VALUES
(1, 'T12538', '2020-10-30', 9, 10, 1, 4000, 'Delivered'),
(2, 'T12538', '2020-10-30', 9, 11, 2, 1200, 'Delivered'),
(3, 'T12538', '2020-10-30', 9, 14, 1, 35, 'Delivered'),
(4, 'T71696', '2020-10-31', 9, 10, 1, 4000, 'Pending'),
(5, 'T71696', '2020-10-31', 9, 14, 10, 350, 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `p_id` int(11) NOT NULL,
  `p_name` varchar(100) NOT NULL,
  `p_price` int(11) NOT NULL,
  `p_description` varchar(200) NOT NULL,
  `p_photo` varchar(50) NOT NULL,
  `p_quantity` int(11) NOT NULL,
  `category_id` varchar(20) NOT NULL,
  `vendor_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`p_id`, `p_name`, `p_price`, `p_description`, `p_photo`, `p_quantity`, `category_id`, `vendor_id`) VALUES
(10, 'Beluga Caviar', 4000, ' This Beluga Caviar is one of the best we have tasted, and many of our regular customers agree.', 'Caviar.jpg', 398, '3', '1'),
(11, 'Black Lumpfish Caviar', 600, 'Substitute in recipes calling for the more traditional roes', 'Black Lumpfish Caviar.jpg', 528, '3', '1'),
(12, 'Alderfer Eggs Cage', 30, 'Free Grade A Large White Eggs', 'Alderfer.jpg', 120, '2', '1'),
(14, 'Nature Yoke Natural', 35, 'Free-Range Large White Eggs', 'Nature.jpg', 9, '2', '1'),
(15, 'Al Zain Brown Eggs', 200, 'Freshly provided directly from Farm', 'eggs_brown_30-01.jpg', 90, '5', '1'),
(27, 'Al Zain Omega Brown Eggs', 400, 'Freshly provided directly from Farm and Rich in Omega.', 'Omega_brown_eggs.jpg', 90, '5', '1'),
(28, 'Hamshire Duck Eggs', 600, '1 Dozen Pack.Delicately hand collected', 'duck.jpg', 20, '7', '1'),
(29, 'Braddock Duck Eggs', 800, '1 Dozen Pack.Magnificent, snowy- white eggs, laid by ducks that live healthy, happy lives.', 'duck2.jpg', 15, '7', '1'),
(30, 'Dartagan Quail Eggs', 2500, '15 Piece Pack. Laid By healthy Quails.', 'Quail.jpg', 8, '6', '1'),
(31, 'Claire Quail Eggs', 1000, '6 Piece Pack. Laid By Free Farm Quails.', 'Quail2.jpg', 30, '6', '1'),
(32, 'Jaya White Eggs  ', 206, '30 Units. Sold only in India', 'Jaya White.jpeg', 20, '2', '2'),
(33, 'Hen Fruit White Eggs', 230, '24 Units. Sold only in India', 'Hen Fruit.jpeg', 30, '2', '2'),
(34, 'Burford Brown Eggs', 180, '6 Units. British Farmed.', 'Burford Browns.jpg', 50, '5', '2'),
(35, 'M&S Brown Eggs', 210, '6 Units. British Farmed.', 'M&S.jpg', 35, '5', '2'),
(38, 'Elsinore Trout Caviar', 430, '50g.Freshly Farmed.', 'Elsinore Trout.jpg', 15, '3', '2'),
(39, 'Elsinore Salmon Cavia', 430, '50g.Freshly Farmed.', 'Elsinore Salmon.jpg', 15, '3', '2'),
(40, 'M&S Quail Eggs', 290, '12 pcs.Freshly Farmed in Britain.', 'M&S Quail Eggs.jpg', 40, '6', '2'),
(41, 'M&S Quail Eggs', 230, '12 pcs.Freshly Farmed in Britain.', 'M&S Quail Eggs.jpg', 60, '6', '2'),
(42, 'Heritage Breeds Duck Eggs', 190, '6 pcs.Freshly Farmed in Britain.', 'Heritage Duck Eggs.jpg', 30, '7', '2'),
(43, 'M&S Duck Eggs', 250, '6 pcs.Freshly Farmed in Britain.', 'M&S Duck Eggs.jpg', 40, '7', '2'),
(46, 'Paleo Duck Eggs', 400, 'Pasture-raised Duck Eggs from Klong Phai farms where they roam freely without any restriction.', 'Paleo.jpg', 90, '7', '2');

-- --------------------------------------------------------

--
-- Table structure for table `vendor`
--

CREATE TABLE `vendor` (
  `id` int(50) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vendor`
--

INSERT INTO `vendor` (`id`, `name`, `email`, `password`, `mobile`, `address`) VALUES
(1, 'Chaitanya Agarwal', 'chaipanch98@gmail.com', 'Chaitanya', '4563728564', 'Chaitanya'),
(2, 'Priti Kochare', 'Kochare@gmail.com', 'Kochare', '9182435728', 'Anyplace devoid of Cats');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_egg`
--
ALTER TABLE `order_egg`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `vendor`
--
ALTER TABLE `vendor`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `order_egg`
--
ALTER TABLE `order_egg`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `vendor`
--
ALTER TABLE `vendor`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
