<head>
    <title>register</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body class="bg-warning">
    <section>
        <!--include navbar here-->
        <?php 
            require('main_navbar.php');
        ?>
    </section>

<section>
        <div class="container">
            <div class="card col-8 offset-2 mt-5 mb-5">
                <div class="card-body">
                    <h1 class="card-title" align="center">CUSTOMER REGISTRATION</h1>
                    <form action="#" method="post">
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" class="form-control" name="name" id="name" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" name="email" id="email" required>
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" class="form-control" name="password" id="password" required>
                        </div>
                        <div class="form-group">
                            <label for="mobile">Mobile number</label>
                            <input type="number" class="form-control" name="mobile" id="mobile" required>
                        </div>
                        <!--<div>
                            <label for="phone">Select User Type</label>
                            <div class="dropdown dropright">
                                <button class="btn btn-warning dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                User Type
                                </button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <a class="dropdown-item" href="#">Customer</a>
                                    <a class="dropdown-item" href="#">Vendor</a>
                                </div>
                            </div>
                        </div>-->
                        <div class="form-group">
                            <label for="address">Address</label>
                            <input type="text" class="form-control" name="address" id="address" required>
                        </div>

                        <div class="container text-center">
                            <button type="submit" class="btn btn-warning">Register</button>
                            <button type="submit" class="btn btn-secondary">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

<?php

    require("connection.php");

    if($_SERVER['REQUEST_METHOD']=='POST')
    {
        $name=$_POST["name"];
        $email=$_POST["email"];
        $password=$_POST["password"];
        $mobile=$_POST["mobile"];        
        $address=$_POST["address"];

        $query="insert into customer(name,email,password,mobile,address) values('".$name."','".$email."','".$password."','".$mobile."','".$address."')";

        mysqli_query($conn,$query);
        
        $affected=mysqli_affected_rows($conn);
        
        mysqli_close($conn);
    }
?>
</body>


