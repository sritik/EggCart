<head>
    <title>register</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body class="bg-warning">
    <section>
        <!--include navbar here-->
        <?php 
            require('main_navbar.php');
        ?>
    </section>

    <section>
        <div class="container">
            <div class="card col-8 offset-2 mt-5 mb-5">
                <div class="card-body">
                    <h1 class="card-title" align="center">REGISTER AS</h1><br>
                    <div class="text-center">
                        <a href="customer_register.php" class="btn btn-warning btn-lg" role="button">Customer</a>
                        &nbsp;
                        <a href="vendor_register.php" class="btn btn-warning btn-lg" role="button">Vendor</a>
                    </div>
                </div>    
            </div>
        </div>
    </section>

</body>


