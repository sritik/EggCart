<head>
    <title>contact</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body class="bg-warning">
    <section>
        <!--include navbar here-->
        <?php 
            require('main_navbar.php');
        ?>
    </section>
<section class="contactus" id="Contact">
    <div class="google-map">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d60256.07490677458!2d72.84151697759167!3d19.282162614192792!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7b0458cf7298b%3A0x468ed839e9df2b21!2sMira%20Road%2C%20Mira%20Bhayandar%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1603976740967!5m2!1sen!2sin" style="border: 0px; --darkreader-inline-border-top: initial; --darkreader-inline-border-right: initial; --darkreader-inline-border-bottom: initial; --darkreader-inline-border-left: initial;" data-darkreader-inline-border-top="" data-darkreader-inline-border-right="" data-darkreader-inline-border-bottom="" data-darkreader-inline-border-left=""></iframe>
    </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="contact-box">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <div class="contact-info">
                                    <div class="contact-image">
                                        <img src="img/contact.png">
                                    </div>
                                </div>
                                <div class="contact-information">
                                    <div class="contact-info-single">
                                        <div class="icon-box">
                                            <i class="fa fa-map-marker" aria-hidden="true"></i>
                                        </div>
                                        <p>795 South Park Avenue, <br>
                                            Shanti Park, Mumbai</p>
                                    </div>
                                    <div class="contact-info-single">
                                        <div class="icon-box">
                                            <i class="fa fa-phone" aria-hidden="true"></i>
                                        </div>
                                        <p>+91 8891181340  <br>    
                                                +91 12312 12312
                                        </p>
                                    </div>
                                    <div class="contact-info-single">
                                        <div class="icon-box">
                                            <i class="fa fa-envelope-o" aria-hidden="true"></i>
                                        </div>
                                            <p>info@vti.com  <br> 
                                                abcd@gmail.com
                                                    </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <div class="contact-form">
                                    <div class="contactus-main-title">
                                        <p>Enter Details</p>
                                        <h2>Get In Touch</h2>
                                    </div>
                                    <form>
                                        <div class="form-group">
                                            <input type="text" name="name" class="form-control" placeholder="Enter Your Name">      
                                        </div>
                                        <div class="form-group">
                                            <input type="mail" name="name" class="form-control" placeholder="Enter Your mail">      
                                        </div>
                                        <div class="form-group">
                                                <textarea class="form-control" rows="5" placeholder="WRITE YOUR MESSAGE HERE"></textarea>
                                        </div>
                                        <div class="form-group">
                                                <input type="submit" class="btn-custom" value="Submit">
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</section>

<footer class="footer-design">
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="siteinfo">
                <p>Copyright © Untitled. All rights reserved. Design By
                <a href="#">VTI Group 2</a>
                </p>
            </div>
            <div class="footer-menu">
                <ul>
                    <li>
                        <a href="#">HOME -</a>
                        <a href="#">COMPARE -</a>
                        <a href="#">CART -</a>
                        <a href="#">CONTACT US -</a>
                        <a href="#">ABOUT US  -</a>
                        <a href="#">LOGIN -</a>
                        <a href="#">REGISTER </a>
                    </li>
                </ul>
            </div>
            <div class="footer-social">
                <a href="#"><span><i class="fa fa-facebook"></i></span></a>
                <a href="#"><span><i class="fa fa-instagram"></i></span></a>
                <a href="#"><span><i class="fa fa-twitter"></i></span></a>
                <a href="#"><span><i class="fa fa-youtube-play"></i></span></a>
            </div>
        </div>
    </div>
</div>
</footer>
</body>