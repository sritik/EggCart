
<?php
    require("connection.php");

    session_start();  

    if($_SERVER['REQUEST_METHOD']=='POST')
    {
        $password=$_POST["password"];
        $email=$_POST["email"];
        $type=$_POST["type"];
        

        if($type=="vendor"){
            $query="select password,name from vendor where email='".$email."'";
        }
        if($type=="customer"){
            $query="select password,name from customer where email='".$email."'";
        }
        
        $result=mysqli_query($conn,$query);
		mysqli_close($conn);
        if (mysqli_num_rows($result)!=0)
        {
            $row=mysqli_fetch_assoc($result);
            if($row["password"]==$password)
            {
                $_SESSION["email"] = $email; 
				$_SESSION["name"] = $row["name"]; 
                //echo"Sucess";
                if($type=="vendor"){
                     header('location:Vendor/home.php');
                 }
                if($type=="customer"){
                    header('location:Customer/home.php');
               }
            }
            else
            {
                
                echo"<script>alert(\"Password Invalid\");</script>";
            }
        }
        else
        {
			echo"<script>alert(\"Email Invalid\");</script>";
 
        }
    
       
    }
?>

<head>
    <title>login</title>
</head>
<body class="bg-warning">
    <section>
        <!--include navbar here-->
        <?php 
            require('main_navbar.php');
        ?>
    </section>

    <section>
        <div class="container">
            <div class="card col-8 offset-2 mt-5">
                <div class="card-body">
                    <h1 class="card-title" align="center">LOGIN HERE</h1>
                    <form action="#" method="post">
                        <div>
                            <label for="type">Type</label>
                            <br>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="type" id="type" value="customer" checked>
                                <label class="form-check-label" for="type">Customer</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="type" id="type" value="vendor">
                                <label class="form-check-label" for="type">Vendor</label>
                            </div>
                        </div><br>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" name="email" id="email" required>
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" class="form-control" name="password" id="password" required>
                        </div>
                        <div class="container text-center">
                            <button type="submit" class="btn btn-warning">Login</button>
                            <button type="submit" class="btn btn-secondary">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
</body>
